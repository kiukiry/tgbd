host = "127.0.0.1"
user = 'postgres'
password = 'Werty-111'
db_name = 'school'