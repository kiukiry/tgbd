import psycopg2
from config import host, user, password, db_name
def execute_query(query):
    try:
        connection = psycopg2.connect(
            host=host,
            user=user,
            password=password,
            database=db_name
        )
        with connection.cursor() as cursor:
            cursor.execute(query)
            if query.strip().upper().startswith('SELECT'):
                result = cursor.fetchall()
                return result
            else:
                connection.commit()
                return True
    except Exception as e:
        print("[INFO] Error executing SQL query:", e)
        return False
    finally:
        if connection:
            connection.close()