import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from telebot import types
from dbbot import execute_query

# Инициализация бота с токеном
bot = telebot.TeleBot("6554670148:AAFwuHZSdTP0MzuUSlq2gW06jdVRI0y0CLA")


# Обработчик команды /start
@bot.message_handler(commands=['start'])
def start_command(message):
    markup = InlineKeyboardMarkup(row_width=2)
    add_student_button = InlineKeyboardButton(text="Добавить ученика", callback_data='add_student')
    delete_student_button = InlineKeyboardButton(text="Удалить ученика", callback_data='delete_student')
    add_teacher_button = InlineKeyboardButton(text="Добавить учителя", callback_data='add_teacher')
    delete_teacher_button = InlineKeyboardButton(text="Удалить учителя", callback_data='delete_teacher')
    students_table_button = InlineKeyboardButton(text="Таблица учеников", callback_data='students_table')

    markup.add(add_student_button, delete_student_button, add_teacher_button, delete_teacher_button,
               students_table_button)
    bot.send_message(message.chat.id, "Выберите действие:", reply_markup=markup)


# Обработчик кнопки "Добавить ученика"
@bot.callback_query_handler(func=lambda call: call.data == 'add_student')
def add_student_callback(call):
    bot.send_message(call.message.chat.id,
                     "Введите данные нового ученика в формате: /add_student <last_name> <first_name> <middle_name> <class_id>")


# Обработчик кнопки "Удалить ученика"
@bot.callback_query_handler(func=lambda call: call.data == 'delete_student')
def delete_student_callback(call):
    bot.send_message(call.message.chat.id, "Введите ID ученика для удаления в формате: /delete_student <student_id>")


# Обработчик кнопки "Добавить учителя"
@bot.callback_query_handler(func=lambda call: call.data == 'add_teacher')
def add_teacher_callback(call):
    bot.send_message(call.message.chat.id,
                     "Введите данные нового учителя в формате: /add_teacher <last_name> <first_name> <middle_name> <class_id> <school_id>")


# Обработчик кнопки "Удалить учителя"
@bot.callback_query_handler(func=lambda call: call.data == 'delete_teacher')
def delete_teacher_callback(call):
    bot.send_message(call.message.chat.id, "Введите ID учителя для удаления в формате: /delete_teacher <teacher_id>")


# Обработчик кнопки "Таблица учеников"
@bot.callback_query_handler(func=lambda call: call.data == 'students_table')
def students_table_callback(call):
    query = "SELECT * FROM students;"
    result = execute_query(query)
    if result:
        students_list = "\n".join(str(row) for row in result)
        bot.send_message(call.message.chat.id, f"Таблица учеников:\n{students_list}")
    else:
        bot.send_message(call.message.chat.id, "Ученики не найдены.")


# Обработчик команды /add_student
@bot.message_handler(commands=['add_student'])
def add_student(message):
    try:
        # Парсинг данных о студенте из сообщения
        student_data = message.text.split()[1:]  # Пропускаем команду /add_student
        last_name, first_name, middle_name, class_id = student_data[:4]
        # Формирование SQL-запроса для добавления студента
        query = f"INSERT INTO students (last_name, first_name, middle_name, class_id) VALUES ('{last_name}', '{first_name}', '{middle_name}', {class_id});"
        # Выполнение запроса
        execute_query(query)
        bot.reply_to(message, "Student added successfully.")
    except Exception as e:
        bot.reply_to(message, f"Error adding student: {e}")


# Обработчик команды /delete_student
@bot.message_handler(commands=['delete_student'])
def delete_student_command(message):
    try:
        # Идентификатор студента, которого нужно удалить
        student_id = message.text.split()[1]  # Пропускаем команду /delete_student

        # Формирование SQL-запроса для удаления студента
        query = f'DELETE FROM students WHERE id = {student_id};'

        # Выполнение запроса
        execute_query(query)

        bot.reply_to(message, "Student deleted successfully.")
    except Exception as e:
        bot.reply_to(message, f"Error deleting student: {e}")


# Обработчик команды /get_students
@bot.message_handler(commands=['get_students'])
def get_students_command(message):
    query = "SELECT * FROM students;"
    result = execute_query(query)
    if result:
        students_list = "\n".join(str(row) for row in result)
        bot.reply_to(message, f"All students:\n{students_list}")
    else:
        bot.reply_to(message, "No students found.")


# Обработчик команды /add_teacher
@bot.message_handler(commands=['add_teacher'])
def add_teacher_command(message):
    bot.reply_to(message, "Please provide the details of the teacher in the format: "
                          "/add_teacher <last_name> <first_name> <middle_name> <class_id> <school_id>")


# Обработчик команды /get_teachers
@bot.message_handler(commands=['get_teachers'])
def get_teachers_command(message):
    query = "SELECT * FROM teachers;"
    result = execute_query(query)
    if result:
        teachers_list = "\n".join(str(row) for row in result)
        bot.reply_to(message, f"All teachers:\n{teachers_list}")
    else:
        bot.reply_to(message, "No teachers found.")


# Обработчик команды /get_schools
@bot.message_handler(commands=['get_schools'])
def get_schools_command(message):
    query = "SELECT * FROM schools;"
    result = execute_query(query)
    if result:
        schools_list = "\n".join(str(row) for row in result)
        bot.reply_to(message, f"All schools:\n{schools_list}")
    else:
        bot.reply_to(message, "No schools")
bot.polling()